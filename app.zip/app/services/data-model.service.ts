import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

@Injectable({
  providedIn: 'root'
})
export class DataModelService {

  constructor(private http: HttpClient) {
  }

  public getPieChartData(): Observable<any> {

  let httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type',
     'Access-Control-Allow-Methods': 'GET'
      }),
      
  //params: new HttpParams().set('program_id', this.program_id)
    };

    return this.http.get("./assets/chart_data.json");
    //return this.http.get("http://localhost:8081/test", httpOptions);
  }
}
