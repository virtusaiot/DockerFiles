import { Component, OnInit } from '@angular/core';
import { DataModelService } from '../services/data-model.service';
declare var splunkjs: any;
import $ from "../../assets/lib/jquery.min";

@Component({
    selector: 'app-piechart',
    templateUrl: './piechart.component.html',
    styleUrls: ['./piechart.component.css']
})
export class PiechartComponent implements OnInit {

    constructor(private dataModelService: DataModelService) { }

    ngOnInit() {
        this.dataModelService.getPieChartData().subscribe(response => {
            console.log(response);
            var results = response.results;
            var chart;
            console.log(results);
            var fields = this.readDataFields(results);
            var fieldInfo = this.extractFieldInfo(results, fields);
            var chartData = this.extractChartReadyData(results, fields, fieldInfo);


            var chartToken = splunkjs.UI.loadCharting("../../assets/lib/splunk.ui.charting.js", function () {
                console.log(results);

                // Once we have the charting code, create a chart and update it.
                chart = new splunkjs.UI.Charting.Chart(document.getElementById("chart_div"), splunkjs.UI.Charting.ChartType.AREA, false);
            });

            splunkjs.UI.ready(chartToken, function () {
                // chart.setData(results, {
                //     "chart": "column",
                //     "chart.stackMode": "default",
                //     "legend.placement": "bottom",
                //     "axisY2.fields": "success",
                //     "axisTitleY.text": "Status",
                //     "axisX2.fields": "_time",
                //     "axisTitleX.text": "Timestamp",
                //     // "yAxisKey" : "success",
                //     // "xAxisKey" : "timestamp",

                //     // "chart": "line",
                //     // "chart.stackMode": "default",
                //     // "legend.placement": "bottom",
                //     // "axisY.minimumNumber": 10,
                //     // "axisY.maximumNumber": 1000,

                // });
                var properties = {
                    "chart.stackMode": "default",
                    "legend.placement": "bottom",
                    "axisY2.fields": fieldInfo.fieldNames,
                    "axisTitleY.text": "Status",
                    "axisY.minimumNumber": 0,
                    "axisY.maximumNumber": 10

                };
                chart.chart.prepare(chartData, fieldInfo, properties);
                chart.draw();
            });

        });
    }

    readDataFields(rawData) {
        if (!rawData) {
            return [];
        }

        return Object.keys(rawData[0]);
    }

    extractFieldInfo(rawData, fields) {
        if (!rawData) {
            return {
                fieldNames: []
            }; 
        }
        var i, loopField, xAxisKey, xAxisSeriesIndex, spanSeriesKey, spanSeriesIndex,
            xAxisKeyFound = false,
            isTimeData = false,
            fieldNames = [];

        // SPL-56805, check for the _time field, if it's there use it as the x-axis field
        var _timeIndex = fields.indexOf('_time');
        if (_timeIndex > -1) {
            xAxisKey = '_time';
            xAxisSeriesIndex = _timeIndex;
            xAxisKeyFound = true;
        }

        for (i = 0; i < fields.length; i++) {
            loopField = fields[i];
            if (loopField == '_span') {
                spanSeriesKey = '_span';
                spanSeriesIndex = i;
                continue;
            }
            if (loopField.charAt(0) == '_' && loopField != "_time") {
                continue;
            }
            if (!xAxisKeyFound) {
                xAxisKey = loopField;
                xAxisSeriesIndex = i;
                xAxisKeyFound = true;
            }
            if (xAxisKey && loopField !== xAxisKey) {
                fieldNames.push(loopField);
            }
        }
        if (xAxisKey === '_time' && (fields.indexOf('_span') > -1 || rawData[xAxisSeriesIndex].length === 1)) {
            // we only treat the data as time data if it has been discretized by the back end
            // (indicated by the existence of a '_span' field)
            isTimeData = true;
        }
        return {
            fieldNames: fieldNames,
            xAxisKey: xAxisKey,
            xAxisSeriesIndex: xAxisSeriesIndex,
            spanSeriesKey: spanSeriesKey,
            spanSeriesIndex: spanSeriesIndex,
            isTimeData: isTimeData
        };
    }

    extractChartReadyData(rawData, fields, fieldInfo) {
        if (!rawData) {
            return false;
        }
        var i, j,
            xAxisKey = fieldInfo.xAxisKey,
            xAxisSeriesIndex = fieldInfo.xAxisSeriesIndex,
            xSeries = [],
            _spanSeries = [], xAxisType, categories,
            loopSeries, loopYVal, loopDataPoint,
            series = {};
        if (xAxisKey === '_time' && (fields.indexOf('_span') > -1 || xSeries.length === 1)) {
            xAxisType = "time";


            // for (i = 0; i < rawData.length; i++) {
            //     if (fields[i] === '_span') {
            //         _spanSeries = rawData.columns[i];
            //         break;
            //     }
            // }
        }
        // else {
        //   xAxisType = "category";
        //   categories = $.extend(true, [], xSeries);
        // }

        // extract the data

        for (var index in fields) {
            series[fields[index]] = [];
        }
        for (i = 0; i < rawData.length; i++) {
            loopSeries = rawData[i];

            xSeries.push(loopSeries[xAxisKey]);
            if (fieldInfo.spanSeriesKey)
                _spanSeries.push(loopSeries[fieldInfo.spanSeriesKey]);
            for (var index in fields) {
                loopDataPoint = {
                    name: loopSeries[xAxisKey],
                    y: parseFloat(loopSeries[fields[index]]),
                    rawY: parseFloat(loopSeries[fields[index]])
                };

                if (xAxisType === "time" && fieldInfo.spanSeriesKey) {
                    loopDataPoint._span = loopSeries[fieldInfo.spanSeriesKey];
                }
                series[fields[index]].push(loopDataPoint);
            }
            // series[fields[i]] = [];
            // for (j = 0; j < loopSeries.length; j++) {
            //     loopYVal = parseFloat(loopSeries[j]);
            //     loopDataPoint = {
            //         name: xSeries[j],
            //         y: loopYVal,
            //         rawY: loopYVal
            //     };
            //     if (xAxisType === "time" && _spanSeries) {
            //         loopDataPoint._span = _spanSeries[j];
            //     }
            //     series[fields[i]].push(loopDataPoint);
            // }
        }
        return {
            series: series,
            fieldNames: fieldInfo.fieldNames,
            xAxisKey: fieldInfo.xAxisKey,
            xAxisType: xAxisType,
            categories: categories,
            xSeries: xSeries,
            _spanSeries: _spanSeries
        };
    }

}
